
  # Data Scientist Portfolio

  This is a code bundle for Data Scientist Portfolio. The original project is available at https://www.figma.com/design/W6d0x6sIRd7STphd9qoYFv/Data-Scientist-Portfolio.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  